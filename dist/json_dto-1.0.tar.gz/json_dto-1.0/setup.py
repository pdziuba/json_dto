from distutils.core import setup

setup(name='json_dto',
      version='1.0',
      py_modules=['json_dto'],
      )
